import React, { useState } from "react";

const sermonLinks = {
  faith: "https://www.youtube.com/watch?v=NsTau5eS5AU",
  provision: "https://www.youtube.com/watch?v=8vbX9JH3e4Q",
  purpose: "https://www.youtube.com/watch?v=uB1EUHtZzq4",
  wisdom: "https://www.youtube.com/watch?v=1A2B3C4D5E6",
  love: "https://www.youtube.com/watch?v=abcdefg1234",
  grace: "https://www.youtube.com/watch?v=hijklmn5678",
};

function App() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [sermon, setSermon] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const findSermon = (text) => {
    const lowerText = text.toLowerCase();
    for (const key in sermonLinks) {
      if (lowerText.includes(key)) {
        return sermonLinks[key];
      }
    }
    return sermonLinks.faith;
  };

  const getBibleQuery = (text) => {
    const keywords = [
      "faith",
      "love",
      "wisdom",
      "hope",
      "grace",
      "peace",
      "provision",
      "joy",
    ];
    for (const word of keywords) {
      if (text.toLowerCase().includes(word)) {
        return word;
      }
    }
    return "psalm 119";
  };

  const fetchBibleVerse = async (query) => {
    try {
      const url = `https://bible-api.com/${encodeURIComponent(
        query
      )}?translation=kjv`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch Bible verse");
      const data = await res.json();
      if (data.verses && data.verses.length > 0) {
        return data.verses.map((v) => v.text).join(" ");
      } else if (data.text) {
        return data.text;
      } else {
        return "No verse found.";
      }
    } catch (e) {
      throw new Error("Error fetching verse.");
    }
  };

  const handleAsk = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setError("");
    setAnswer("");
    setSermon("");
    try {
      const bibleQuery = getBibleQuery(question);
      const verseText = await fetchBibleVerse(bibleQuery);
      const sermonLink = findSermon(question);
      setAnswer(`Scripture (${bibleQuery.toUpperCase()}): ${verseText}`);
      setSermon(sermonLink);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        maxWidth: 600,
        margin: "auto",
        padding: 20,
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1 style={{ color: "#0070f3", textAlign: "center" }}>LightHub</h1>
      <p style={{ textAlign: "center", color: "#555" }}>
        Spiritual insight. Biblical answers. Guided by Light.
      </p>
      <textarea
        rows={5}
        style={{
          width: "100%",
          fontSize: 16,
          padding: 10,
          borderRadius: 8,
          borderColor: "#ccc",
        }}
        placeholder="Type your biblical or spiritual question here..."
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
      />
      <button
        onClick={handleAsk}
        disabled={loading || !question.trim()}
        style={{
          marginTop: 10,
          width: "100%",
          padding: 15,
          fontSize: 18,
          fontWeight: "bold",
          backgroundColor: "#0070f3",
          color: "white",
          border: "none",
          borderRadius: 8,
          cursor: loading || !question.trim() ? "not-allowed" : "pointer",
        }}
      >
        {loading ? "Loading..." : "Get Answer & Sermon"}
      </button>
      {error && <p style={{ color: "red", marginTop: 10 }}>{error}</p>}
      {answer && (
        <div
          style={{
            backgroundColor: "#f0f8ff",
            padding: 15,
            borderRadius: 8,
            marginTop: 20,
          }}
        >
          <h3>Biblical Answer:</h3>
          <p>{answer}</p>
        </div>
      )}
      {sermon && (
        <a
          href={sermon}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "block",
            backgroundColor: "#dbeafe",
            padding: 15,
            borderRadius: 8,
            marginTop: 15,
            textAlign: "center",
            fontWeight: "bold",
            color: "#0070f3",
            textDecoration: "none",
          }}
        >
          Recommended Sermon: Tap to watch
        </a>
      )}
      <p
        style={{
          marginTop: 40,
          fontSize: 12,
          color: "#aaa",
          textAlign: "center",
        }}
      >
        Created by Odu Peter Adedamola (Christoap) • © {new Date().getFullYear()}{" "}
        LightHub
      </p>
    </div>
  );
}

export default App;